function setRule(id, pass) {

}

var checkPassword = function(pw) {
	console.log(pw);
	// blank password
	
	// must be 5 characters or MORE


	// check for mixed case


	// check for password


	// no @


	// no .

};