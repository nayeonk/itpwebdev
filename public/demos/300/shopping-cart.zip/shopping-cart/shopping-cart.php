<?php

/*
	To display shopping cart items on a page, we need to pull the product
	ids from the user's session. Then we need to query the db for the
	product details for all of the products. We can do this using a 
	WHERE IN clause. This allows us to query for products that match
	multiple IDs, instead of just 1.
*/

session_start();
$productIDs = $_SESSION['shoppingCart'];
$in_clause = implode(',', $productIDs);
$sql = "SELECT * FROM products WHERE id IN ($in_clause)";