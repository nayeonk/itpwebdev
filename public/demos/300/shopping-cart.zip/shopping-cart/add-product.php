<?php

/*
	To store products in a session, we need to initialize a session as
	an array. An array is a list of data, so we will have a session
	variable called shoppingCart and it will contain a list of product
	IDs.
*/

session_start();

if (!is_array($_SESSION['shoppingCart'])) {
	$_SESSION['shoppingCart') = array();
}

$productID = $_GET['id'];
array_push($_SESSION['shoppingCart'], $productID);

header('Location: products.php');
exit();





