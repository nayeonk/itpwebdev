<?php

// dump session information onto the page just for debugging
session_start();
var_dump($_SESSION);