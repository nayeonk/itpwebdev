<!doctype html>
<html>
<head>
	<title>Login</title>
</head>
<body>

<form method="post" action="login-process.php">
	Username: <input type="text" name="username" />
	Password: <input type="password" name="pw" />
	<input type="submit" value="Login" />
</form>

</body>
</html>