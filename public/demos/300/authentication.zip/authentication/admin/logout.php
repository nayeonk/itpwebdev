<?php

// destroy the session and redirect back to the login form 
session_start();
session_destroy();

header('Location: ../login.php');
exit();