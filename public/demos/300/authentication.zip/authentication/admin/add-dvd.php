<?php require 'authenticate.php'; ?>

<h1>Admin - Add DVD</h1>

<a href="index.php">Admin Home</a>
<a href="logout.php">Logout</a>