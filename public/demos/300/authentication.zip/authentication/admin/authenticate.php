<?php

/*
	this page is responsible for checking if the user is logged in.
	if the user isnt redirect them back to the login page.
	you can include this file on any page that require authentication
	before viewing.
*/

session_start();
if (empty($_SESSION['loggedin'])) {
	header('Location: ../login.php');
}

	