<?php require 'authenticate.php'; ?>
<h1>Admin - Home</h1>

<a href="add-dvd.php">Add DVD</a>
<a href="logout.php">Logout</a>