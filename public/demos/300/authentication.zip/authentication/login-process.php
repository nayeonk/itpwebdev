<?php

// if the user did not come from the login form, redirect to login page
if (empty($_POST['username']) || empty($_POST['pw'])) {
	header('Location: login.php');
	exit();
}

$username = $_POST['username'];
$password = $_POST['pw'];

$con = mysql_connect('localhost', 'dtang', 'ttrojan');
mysql_select_db('dtang');

// check if the typed credentials match a record in the users table
// because passwords are encrypted in users table, we need to encrypt
// the password that the user typed in
$sql = "
	SELECT * FROM users
	WHERE username = '$username' AND
	pw = SHA1('$password')
";

$result = mysql_query($sql);
$rowCount = mysql_num_rows($result);

// if at least one record was found in the users table, that means
// an account exists and we can successfully log them in and take 
// them to the admin home page
if ($rowCount >= 1) {
	// entered successful credentials
	session_start();
	$_SESSION['loggedin'] = true;
	$_SESSION['username'] = 'dtang';
	
	header('Location: admin/index.php');
	exit();
} else {
	// entered in bad credentials
	header('Location: login.php');
	exit();
}

